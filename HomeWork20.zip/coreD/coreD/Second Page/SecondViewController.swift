//
//  SecondViewController.swift
//  coreD
//
//  Created by Natia's Mac on 06/11/2021.
//

import UIKit
import CoreData

class SecondViewController: UIViewController {
   
    @IBOutlet weak var addedtext: UILabel!
    @IBOutlet weak var addBtn: UIButton!
    @IBOutlet weak var enterDate: UIDatePicker!
    @IBOutlet weak var enterText: UITextView!
    @IBOutlet weak var enterAuthor: UITextField!
    @IBOutlet weak var enterTitle: UITextField!
    
    @IBOutlet weak var enterGenre: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        addBtn.layer.cornerRadius = 5
        
        // Do any additional setup after loading the view.
    }
  

    @IBAction func addArticle(_ sender: UIButton) {
        let savedDate = enterDate.date
        guard let savedTitle = enterTitle.text,
              let savedAuthor = enterAuthor.text,
              let savedGenre = enterGenre.text,
              let savedText = enterText.text
        else { return }
        
        self.save( date: savedDate, title: savedTitle, author: savedAuthor, genre: savedGenre, text: savedText )
        addedtext.text = " New Article Has Been Added, Thank You!"
       
                 let sb = UIStoryboard(name: "Main", bundle: nil)
               let vc = sb.instantiateViewController(withIdentifier: "ViewController")as! ViewController

        DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
           
            self.present(vc, animated: true, completion: nil)
                // vc.dismiss(animated: true, completion: nil)
        }
        
    }

    func save(date: Date, title: String, author: String, genre: String, text: String) {
      
      guard let appDelegate =  UIApplication.shared.delegate as? AppDelegate else { return }
      
        let managedContext = appDelegate.persistentContainer.viewContext
      
        let entity = NSEntityDescription.entity(forEntityName: "Article",
                                   in: managedContext)!
        let article = NSManagedObject(entity: entity,
                                   insertInto: managedContext)
      
    
        article.setValue(date, forKeyPath: "date")
        article.setValue(title, forKeyPath: "title")
        article.setValue(author, forKeyPath: "author")
        article.setValue(genre, forKeyPath: "genre")
        article.setValue(text, forKeyPath: "text")
        
       
      
      do {
        try managedContext.save()
        articles.insert(article, at: 0)
        
      } catch let error as NSError {
        print("Could not save. \(error), \(error.userInfo)")
      }
    }
}

