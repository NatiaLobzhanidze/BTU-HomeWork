//
//  ArticleTableViewCell.swift
//  coreD
//
//  Created by Natia's Mac on 06/11/2021.
//

import UIKit
import CoreData

class ArticleTableViewCell: UITableViewCell {
    @IBOutlet weak var authorInfo: UILabel!
    @IBOutlet weak var articleText: UILabel!
    @IBOutlet weak var genreInfo: UILabel!
    @IBOutlet weak var titleInfo: UILabel!
    @IBOutlet weak var dateInfo: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
       
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    public func configure( with item: NSManagedObject){
        authorInfo.text = "Author: " + (item.value(forKey: "author")as? String ?? " ")
        titleInfo.text = "Title: " + (item.value(forKey: "title")as? String  ?? " ")
        articleText.text = item.value(forKey: "text")as?  String
        genreInfo.text = "Genre: " + (item.value(forKey: "genre")as? String  ?? " ")
        dateInfo.text = "\( item.value(forKey: "date")!)"
    }
    
    
}
