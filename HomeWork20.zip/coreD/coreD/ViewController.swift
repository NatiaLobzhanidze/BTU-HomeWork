//
//  ViewController.swift
//  coreD
//
//  Created by Natia's Mac on 06/11/2021.
//

import UIKit
import CoreData

public var articles: [NSManagedObject] = []

class ViewController: UIViewController {

    @IBOutlet weak var tableView: UITableView!
    


    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.dataSource = self
        tableView.register(UINib(nibName: "ArticleTableViewCell", bundle: nil),
                           forCellReuseIdentifier: "ArticleTableViewCell")
       // deleteAllData(entity: "Article")
        tableView.reloadData()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        fetchData()
        tableView.reloadData()
    }
    
    
    func fetchData(){
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else { return }
        
        let managedContext = appDelegate.persistentContainer.viewContext
        
        let fetchRequest =  NSFetchRequest<NSManagedObject>(entityName: "Article")
        
        do {
           articles = try managedContext.fetch(fetchRequest)
            
         }  catch let error as NSError {
          
            print("Could not fetch. \(error), \(error.userInfo)")
            }
        
    }
    
    
    func deleteAllData(entity: String) {

        guard let appDelegate =
          UIApplication.shared.delegate as? AppDelegate else {
          return
        }
        let managedContext = appDelegate.persistentContainer.viewContext

        let entity = NSEntityDescription.entity(forEntityName: "Article",
                                     in: managedContext)!


       let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "Article")
        
           fetchRequest.returnsObjectsAsFaults = false

        do {
               let results = try managedContext.fetch(fetchRequest)
               for object in results {
                   guard let objectData = object as? NSManagedObject else { continue }
                   managedContext.delete(objectData)
                   try managedContext.save()
               }
           } catch let error {
               print("Detele all data in \(entity) error :", error)
           }

}

}
extension ViewController: UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return articles.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "ArticleTableViewCell", for: indexPath)as! ArticleTableViewCell
        cell.configure(with: articles[indexPath.row])
        return cell
    }
    
}


